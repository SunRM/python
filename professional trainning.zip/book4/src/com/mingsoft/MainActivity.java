package com.mingsoft;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main); // ���ø�Activityʹ�õĲ���
		
		
		Button mbutton=(Button)findViewById(R.id.mbutton);
        mbutton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(MainActivity.this,Bookclassify.class);
				startActivity(intent);
			}
		});
        Button sbutton=(Button)findViewById(R.id.sbutton);
        sbutton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				Intent intent=new Intent(MainActivity.this,SaleActivity.class);
				startActivity(intent);
			}
		});
        
        
		Button button=(Button)findViewById(R.id.m_exit);	//��ȡ���˳���¼����ť
		button.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				finish();		//�رյ�ǰActivity
			}
		});
	}
}
