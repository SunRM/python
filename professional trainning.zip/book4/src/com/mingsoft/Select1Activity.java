package com.mingsoft;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class Select1Activity extends Activity {
	
	
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.select);	    	
	        WebView webview=(WebView)findViewById(R.id.webView2);  //��ȡwebview���
	        webview.loadUrl("http://mysjcserver.iok.la/bookserver/lookrw.jsp");//����Ĭ����ʾ��Ϣ
		     //��web����зŴ����С��ҳ�Ĺ���
		       webview.getSettings().setSupportZoom(true);
		       webview.getSettings().setBuiltInZoomControls(true);
		       //
		       webview.getSettings().setJavaScriptEnabled(true);  //����js����
		       webview.setWebChromeClient(new WebChromeClient());
		       
		       webview.setWebViewClient(new WebViewClient());
	       	        
	    }

	public void onClick(View view) {
		// TODO Auto-generated method stub
		
	}
}
