package com.mingsoft;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import java.net.HttpURLConnection;
import java.net.URL;

public class NewsService {
       public static boolean save(String username,String password){
    	   HttpURLConnection conn=null;
    	   try{
    		   String data="username="+username+"&password="+password;
    		   URL url=new URL("http://mysjcserver.iok.la/bookserver/LoginServlet?"+data);  
               conn=(HttpURLConnection) url.openConnection();  
               conn.setRequestMethod("GET");  
               conn.setConnectTimeout(10000);  
               conn.setReadTimeout(5000);  
               conn.connect();  
               int code=conn.getResponseCode();  
               if(code==200){  
                     
                   String state="success";  
                  boolean b=true;
               }
    	   }catch(Exception e){
    		  e.printStackTrace(); 
    	   }finally{
    		   if(conn!=null){  
                   conn.disconnect(); 
    	   }
    		   }
		return false;
    	  
       }


}