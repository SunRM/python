package com.mingsoft;

import android.app.Activity;

import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;


public class SaleActivity extends Activity {
	
	
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.select);	    	
	        WebView webview=(WebView)findViewById(R.id.webView2);  //��ȡwebview���
	        webview.loadUrl("http://mysjcserver.iok.la/bookserver/index.jsp");//����Ĭ����ʾ��Ϣ
		     //��web����зŴ����С��ҳ�Ĺ���
		       webview.getSettings().setSupportZoom(true);
		       webview.getSettings().setBuiltInZoomControls(true);
		       //
		       webview.getSettings().setJavaScriptEnabled(true);  //����js����
		       webview.setWebChromeClient(new WebChromeClient());
		       
		       webview.setWebViewClient(new WebViewClient());
	       	        
	    
    Button exbutton=(Button)findViewById(R.id.w_exit2);
   
    exbutton.setOnClickListener(new OnClickListener() {
		
		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
		finish();
		}
	});
	
}
}