package com.mingsoft;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;

public class Select2Activity extends Activity {
	
	
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.select);	    	
	       WebView webview=(WebView)findViewById(R.id.webView2);  //��ȡwebview���
	     //��web����зŴ����С��ҳ�Ĺ���
	       webview.getSettings().setSupportZoom(true);
	       webview.getSettings().setBuiltInZoomControls(true);
	       //
	       webview.getSettings().setJavaScriptEnabled(true);  //����js����
	       webview.setWebChromeClient(new WebChromeClient());
	       webview.loadUrl("http://mysjcserver.iok.la/booksever/book_list.jsp");//����Ĭ����ʾ��Ϣ
	       	        
	    }

	public void onClick(View view) {
		// TODO Auto-generated method stub
		
	}
}
