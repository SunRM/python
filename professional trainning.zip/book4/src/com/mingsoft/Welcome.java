package com.mingsoft;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class Welcome extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.welcome);//���õ�ǰ��ͼΪmain  
	       final Intent it = new Intent(Welcome.this, LoginActivity.class); //��һ��ת��Mainctivity  
	       Timer timer = new Timer();  
	       TimerTask task = new TimerTask() {  
	           @Override  
	           public void run() {  
	               startActivity(it);
	               Welcome.this.finish(); //ִ����ͼ  
	           }  
	       };  
	       timer.schedule(task, 1000 * 3); //3�����ת����������Լ���Ҫ�趨ʱ��  
	   }  
}
