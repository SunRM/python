package com.mingsoft;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;

public class RegActivity extends Activity {
	 protected void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.register);	    	
	        WebView webview=(WebView)findViewById(R.id.webView1);  //��ȡwebview���
	        webview.loadUrl("http://mysjcserver.iok.la/bookserver/userreg.jsp");//����Ĭ����ʾ��Ϣ
		     //��web����зŴ����С��ҳ�Ĺ���
		       webview.getSettings().setSupportZoom(true);
		       webview.getSettings().setBuiltInZoomControls(true);
		       //
		       webview.getSettings().setJavaScriptEnabled(true);  //����js����
		       webview.setWebChromeClient(new WebChromeClient());
		       
		       webview.setWebViewClient(new WebViewClient());
		       
		       Button exbutton1=(Button)findViewById(R.id.w_exit1);
		       
		       exbutton1.setOnClickListener(new OnClickListener() {
		   		
		   		@Override
		   		public void onClick(View v) {
		   			// TODO Auto-generated method stub
		   		finish();
		   		}
		   	});
}
	 
}
