package com.mingsoft;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Bookclassify extends Activity {
	protected void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
			setContentView(R.layout.bookclassify);
			Button rwbutton=(Button)findViewById(R.id.renweng_button);
	        rwbutton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent intent=new Intent(Bookclassify.this,Select1Activity.class);
					startActivity(intent);
				}
			});
	        Button zrbutton=(Button)findViewById(R.id.zirang_button);
	        zrbutton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
				Intent intent=new Intent(Bookclassify.this,Select2Activity.class);	
				startActivity(intent);
				}
			});
	        Button skbutton=(Button)findViewById(R.id.sheke_button);
	        skbutton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
				Intent intent=new Intent(Bookclassify.this,Select3Activity.class);	
				startActivity(intent);
				}
			}); 
	        Button ysbutton=(Button)findViewById(R.id.yishu_button);
	        ysbutton.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					// TODO Auto-generated method stub
				Intent intent=new Intent(Bookclassify.this,Select4Activity.class);	
				startActivity(intent);
				}
			}); 
	 }
}
