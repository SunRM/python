package commm;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ResetServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public ResetServlet() {
		super();
	}

	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		
		response.setCharacterEncoding("utf-8");
		String name=request.getParameter("username").toString();//��ȡ�ͻ��˴���������û���
		String password=request.getParameter("password").toString();//��ȡ����������û�����	
		String email=request.getParameter("email").toString();
		
		
		
		boolean b=new ResetFunction().resetFunction(name,password,email);
		PrintWriter out = response.getWriter();
		out.write(b+"200");
		out.flush();
		out.close();
	}

}
