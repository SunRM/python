package commm;

import java.io.IOException;



import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
	}
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

            doPost(request,response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("utf-8");
		
		response.setCharacterEncoding("utf-8");
		String username=request.getParameter("username").toString();//��ȡ�ͻ��˴���������û���
		String password=request.getParameter("password").toString();//��ȡ����������û�����		
		
		boolean bbb=new CheckLogin().checkLogin(username,password);//�ж��û����������Ƿ���ȷ
		if(bbb)//��ȷ
		{
			 response.getWriter().println("success");
		}else{
			response.getWriter().println("failed");
		}
	}
}


