package commm;

import java.net.URLDecoder;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class ResetFunction {
	public boolean resetFunction(String username ,String password,String email){
		 Connection conn=null;
		 PreparedStatement pt=null;
		 boolean b=true;
		 try{
			 conn=Db.getCon();
			 String sq="INSERT INTO userinfo(username,password,email) VALUES(?,?,?)";
			 pt=(PreparedStatement) conn.prepareStatement(sq);
			 pt.setString(1, URLDecoder.decode(username,"utf-8"));
			 pt.setString(2, URLDecoder.decode(password,"utf-8"));
			 pt.setString(3, URLDecoder.decode(email,"utf-8"));
			 pt.executeUpdate();
			 pt.close();
			 conn.close();			 
		 }catch(Exception ww){
			 ww.printStackTrace();
			 b=false;
			 try{
				 conn.rollback();
				 }
			 catch(Exception wq){
				 wq.printStackTrace();
				 }
		 }
		 return b;
	}

}
