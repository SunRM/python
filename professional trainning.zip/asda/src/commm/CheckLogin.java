package commm;

import java.sql.PreparedStatement;

import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.Connection;



public class CheckLogin {
	//��¼���
		 public boolean checkLogin(String username ,String password){
			 Connection conn=null;
			 Statement stmt=null;
			 ResultSet rs=null;
			boolean b=false;
			 try{
				 conn=Db.getCon();//��ȡ����
				stmt=conn.createStatement();
				String sql="select * from userinfo where username='"+username+"' and password='"+password+"'";  
				rs=stmt.executeQuery(sql);
				
			     
				
				 boolean haveName=rs.next();
				 
				 if(!haveName)
				 {
					 b=false;				
				 }
				 else{
					 b=true;
				 }
			//	 stmt1.close();
			//	 conn.close();
				 
			 }catch(Exception sw){
				 sw.printStackTrace();
				
			 }finally{
				 try{
					 rs.close();
					 stmt.close();
					 conn.close();
				 }catch(Exception e){
					 e.printStackTrace();
				 }
			 }
			return b;
		 }

}
