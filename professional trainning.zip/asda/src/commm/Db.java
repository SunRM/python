package commm;

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;

public class Db {
	public static Connection getCon(){
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		
		String url="jdbc:mysql://localhost:3306/mydb";
		//String url="jdbc:mysql://?.?.?.?:3306/mobilelearning?useUnicode=true&characterEncoding=gb2312";
		try {
			
			con=(Connection) DriverManager.getConnection(url,"root","asdfg");//���ݿ���û���������
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		return con;
	}

}
